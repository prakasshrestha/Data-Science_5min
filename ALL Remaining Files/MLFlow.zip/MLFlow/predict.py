import mlflow.pyfunc
import numpy as np

mlflow.set_tracking_uri("http://127.0.0.1:5000")
model = mlflow.pyfunc.load_model(
    "models:/IrisRandomForest@production"
)

sample = np.array([[5.1, 3.5, 1.4, 0.2]])
print("Prediction:", model.predict(sample))

